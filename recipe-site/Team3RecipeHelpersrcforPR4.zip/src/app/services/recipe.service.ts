import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Recipe } from '../recipe';

@Injectable({
  providedIn: 'root',
})
export class RecipeService {
  hostUrl: string = 'http://localhost:8080/';

  constructor(private http: HttpClient) {}

  getRecipeList(path: string) {
    return this.http.get(this.hostUrl + path);
  }

  getARecipeList(path: string, id: string) {
    return this.http.get(this.hostUrl + path + id);
  }

  getRecipe(id: string): Observable<Recipe> {
    return this.http.get<Recipe>(this.hostUrl + 'recipe/' + id);
  }
}
